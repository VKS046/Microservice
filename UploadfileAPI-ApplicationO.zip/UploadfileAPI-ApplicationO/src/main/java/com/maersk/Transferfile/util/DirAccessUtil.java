package com.maersk.Transferfile.util;

import com.maersk.Transferfile.model.FileModel;

import java.io.File;
import java.util.Date;
import java.util.List;

public class DirAccessUtil {

    public List<FileModel> addFilesNameToList(File[] listOfFiles, List<FileModel> list) {
        for (int i = 0; i < listOfFiles.length; i++) {
            FileModel FileModelObj = new FileModel();
            FileModelObj.FileName = listOfFiles[i].getName();
            long millisec = listOfFiles[i].lastModified();
            Date dt = new Date(millisec);
            FileModelObj.FileDate = dt;
            list.add(FileModelObj);
        }
        return  list;
    }
}