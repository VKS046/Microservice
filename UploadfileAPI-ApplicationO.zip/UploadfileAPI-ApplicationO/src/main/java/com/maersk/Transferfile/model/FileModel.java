package com.maersk.Transferfile.model;

import java.util.Date;


public class FileModel {

    public String FileName;

    public Date FileDate;

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String fileName) {
        FileName = fileName;
    }

    public Date getFileDate() {
        return FileDate;
    }

    public void setFileDate(Date fileDate) {
        FileDate = fileDate;
    }

}
