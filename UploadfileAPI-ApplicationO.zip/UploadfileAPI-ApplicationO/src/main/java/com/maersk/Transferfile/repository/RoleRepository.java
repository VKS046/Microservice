package com.maersk.Transferfile.repository;

import com.maersk.Transferfile.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
