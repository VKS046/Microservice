
package com.maersk.Transferfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransferfileApplicationTests {

	@Test
	void contextLoads() {
	}

}

