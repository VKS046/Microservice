package com.hellokoding.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.hellokoding.auth.model.Doc;

public interface DocRepository  extends JpaRepository<Doc,Integer>{

}
